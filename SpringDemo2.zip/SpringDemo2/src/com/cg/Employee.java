package com.cg;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp2")
public class Employee {
	
	@Value("112081")
	private int empId;
	@Value("Amarendra")
	private String empName;
	@Value("1000.0")
	private float empSal;
	
	@Autowired 
	@Qualifier("dept1")
	private Department empDemp;
    
	@Resource(name="getEmpWorkLoc")
	private ArrayList<String> empWorkLoc;
	
	private java.sql.Date empDOJ;
	private LocalDate empDOB;
	
	public Employee() {
		super();
		
	}
	
	
	
	public Employee(int empId, String empName, float empSal, Department empDemp, ArrayList<String> empWorkLoc,
			Date empDOJ) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDemp = empDemp;
		this.empWorkLoc = empWorkLoc;
		this.empDOJ = empDOJ;
	}



	public Employee(int empId, String empName, float empSal, Department empDemp) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDemp = empDemp;
	}



	public Department getEmpDemp() {
		return empDemp;
	}



	public void setEmpDemp(Department empDemp) {
		this.empDemp = empDemp;
	}



	public LocalDate getEmpDOB() {
		return empDOB;
	}



	public void setEmpDOB(LocalDate empDOB) {
		this.empDOB = empDOB;
	}



	public Date getEmpDOJ() {
		return empDOJ;
	}
	public void setEmpDOJ(Date empDOJ) {
		this.empDOJ =  empDOJ;
	}
	public ArrayList<String> getEmpWorkLoc() {
		return empWorkLoc;
	}
	public void setEmpWorkLoc(ArrayList<String> empWorkLoc) {
		this.empWorkLoc = empWorkLoc;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public Department getDept() {
		return empDemp;
	}
	public void setDept(Department dept) {
		this.empDemp = dept;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empDemp=" + empDemp
				+ ", empWorkLoc=" + empWorkLoc + ", empDOJ=" + empDOJ + "]";
	}
	
	
	
	
	
	
	
	
	

}
