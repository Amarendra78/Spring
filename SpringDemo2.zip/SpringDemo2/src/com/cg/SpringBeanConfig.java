package com.cg;
import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringBeanConfig {

	@Bean
	public ArrayList<String> getEmpWorkLoc()
	{
		ArrayList<String> cityList=new ArrayList<String>();
		cityList.add("Noida");
		cityList.add("pube");
		cityList.add("Mumbai");
		return cityList;
	}
}
