package com.cg.demo.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.ITraineeDao;
import com.cg.demo.dto.Trainee;

@Service
@Transactional
public class TraineeService implements ITraineeService
{
	@Autowired
	ITraineeDao traineeDao=null;

	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public Trainee addTraineeDetails(Trainee tr)
	{
		return traineeDao.addTraineeDetails(tr);
	}

	@Override
	public void deleteTraineeDetails(int unm)
	{
		
		traineeDao.deleteTraineeDetails(unm);
		
	}

	@Override
	public ArrayList<Trainee> fetchAllUsers(int id) {
		// TODO Auto-generated method stub
		return traineeDao.fetchAllUsers(id);
	}

	@Override
	public ArrayList<Trainee> fetchAllUsers() {
		// TODO Auto-generated method stub
		return traineeDao.fetchAllUsers();
	}

	@Override
	public void ModifyTraineeDetails(int unm) {
	traineeDao.ModifyTraineeDetails(unm);
		
	}
	
	

}
