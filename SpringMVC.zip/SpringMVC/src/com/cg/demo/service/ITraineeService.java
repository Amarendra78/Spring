package com.cg.demo.service;
import java.util.ArrayList;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Trainee;


public interface ITraineeService
{
	Trainee addTraineeDetails(Trainee tr);
	public void deleteTraineeDetails(int unm);
	public ArrayList<Trainee> fetchAllUsers(int id);
	ArrayList<Trainee> fetchAllUsers();
	public void ModifyTraineeDetails(int unm);
	
}
