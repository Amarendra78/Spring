package com.cg.demo.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.demo.dto.Login;

import com.cg.demo.dto.Trainee;
import com.cg.demo.service.ITraineeService;
import com.cg.demo.service.TraineeService;


@Controller
public class TraineeController
{
	int id;
	int id1;
	@Autowired
    ITraineeService traineeService=null;

	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping(value="/ShowLoginPage1",method = RequestMethod.GET)
	public String dispHomePage1(Model model)
	{

		Trainee reg=new Trainee();
		model.addAttribute("userObj", reg);
		ArrayList<String> domain=new ArrayList<String>();
		domain.add("Java");
		domain.add("DotNet");
		model.addAttribute("cDomain",domain);
		return "AddTrainee";
		
		
	}
	@RequestMapping(value = "/ValidateUser", method = RequestMethod.POST)
	public String isUserValid(@ModelAttribute("login") @Valid Login lgg, BindingResult result, Model model) {
		
		
				if (lgg.getUsername().equalsIgnoreCase("admin") && lgg.getPassword().equalsIgnoreCase("admin")) {
					String msg = "Welcome U R Valid user";
					model.addAttribute("msgObj", msg);
					return "Crude";
				} else {
					String msg = "Sorry Invalid Password";
					model.addAttribute("msgObj", msg);
					return "Login";
				}


		}
	@RequestMapping(value="/InsertUserDetails",method = RequestMethod.POST)
	public String addUser(@ModelAttribute("userObj") Trainee reg,BindingResult result,Model model)
	{
		
		
		model.addAttribute("UserDataObj", reg);
		traineeService.addTraineeDetails(reg);
		return "ListAllUser";
		
	}
	@RequestMapping(value="/DeleteUser")
	public String dispHomePage2(Model model)
	{
	   
		System.out.print(id+"deleted");
		traineeService.deleteTraineeDetails(id);
		return "del";
		
	}
	@RequestMapping(value="/ModifyUserCon")
	public String dispHomePage25(Model model)
	{
	   
		
		traineeService.ModifyTraineeDetails(id1);
		return "Mod";
		
	}
	
	@RequestMapping(value="/ShowAllUserDetails1")
	public String dispAllUserDetails1(Model model)
	{
		Trainee tg=new Trainee();
		model.addAttribute("delObj", tg);
		return "Delete";
	}

	@RequestMapping(value="/ShowAllUserDetails21")
	public String dispAllUserDetails13(Model model)
	{
		Trainee tg=new Trainee();
		model.addAttribute("modObj", tg);
		return "Modify";
	}
	@RequestMapping(value="/ShowAllUserDetails25", method = RequestMethod.POST)
	public String isUserValid30(@ModelAttribute("modObj") @Valid Trainee lgg, BindingResult result, Model model)
	{
		
		id1=lgg.getTraineeId();
		System.out.println(id1+"in controller");
		ArrayList<Trainee> uList=traineeService.fetchAllUsers(id1);
		model.addAttribute("UserListObj", uList);
		return "ModifyUser";
	}
	@RequestMapping(value="/ShowAllUserDetails", method = RequestMethod.POST)
	public String isUserValid(@ModelAttribute("delObj") @Valid Trainee lgg, BindingResult result, Model model)
	{
		
		id=lgg.getTraineeId();
		System.out.println(id+"in controller");
		ArrayList<Trainee> uList=traineeService.fetchAllUsers(id);
		model.addAttribute("UserListObj", uList);
		return "DelUser";
	}
	@RequestMapping(value="/ShowAllUserDetails2")
	public String dispAllUserDetails2(Model model)
	{
		ArrayList<Trainee> uList=traineeService.fetchAllUsers();
		model.addAttribute("UserListObj", uList);
		return "DelUser1";
		
	}
	@RequestMapping(value="/ShowAllUserDetails3", method = RequestMethod.POST)
	public String isUserValid11(@ModelAttribute("retrieveObj") @Valid Trainee lgg, BindingResult result, Model model)
	{
		
		id=lgg.getTraineeId();
		System.out.println(id+"in controller");
		ArrayList<Trainee> uList=traineeService.fetchAllUsers(id);
		model.addAttribute("UserListObj", uList);
		return "RetrieveUser";
	}
	@RequestMapping(value="/ShowAllUserDetails11")
	public String dispAllUserDetails11(Model model)
	{
		Trainee tg=new Trainee();
		model.addAttribute("retrieveObj", tg);
		return "Retrieve2";
	}
	
}


	

