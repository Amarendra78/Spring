package com.cg.demo.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;
import com.cg.demo.service.ILoginService;
import com.cg.demo.service.ILoginService;


@Controller
//@RequestMapping("/loginCtrl")  
public class LoginController {
	
	/*@RequestMapping("/ShowLoginPage")
	public String showLoginPage()
	{
		return "Login";
	}*/
	@Autowired
	ILoginService  logServ= null;
	public ILoginService getLogServ() {
		return logServ;
	}
	public void setLogServ(ILoginService logServ) {
		this.logServ = logServ;
	}
	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String showLoginPage(Model model)
	{
		Login lg=new Login();
		String msg="Today is: "+LocalDate.now();
		model.addAttribute("msgObj", msg);
		model.addAttribute("loginObj", lg);
		return "Login";

	}
	
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginObj") 
	@Valid Login lgg, BindingResult result,Model model)
	{
		if(result.hasErrors()) {
			return "Login";
		}
		else {
		Login user=logServ.validateUser(lgg);
		if(user!=null)
		{
			if(user.getPassword().equalsIgnoreCase(lgg.getPassword()))
					{
				String msg="Welcome U R Valid User :"+user.getUsername();
					model.addAttribute("MsgObj", msg);
			return "Success";
		}
		else 
			{
		String msg="Sorry  InValid User";
			model.addAttribute("MsgObj", msg);
			return "Login";
		}
	
		
	}
		else
		{
			Register reg=new Register();
			model.addAttribute("userObj",reg);
			ArrayList<String> cityList=new ArrayList<String>();
			cityList.add("Pune");
			cityList.add("Noida");
			cityList.add("Nagpur");
			cityList.add("Mumbai");
			model.addAttribute("cList", cityList);
			
			ArrayList<String> skills=new ArrayList<String>();
			skills.add("java");
			skills.add("oracle");
			skills.add("BI");
			skills.add("html");
	model.addAttribute("skillList", skills);
			
			return "Register";
		}
		}
	}

@RequestMapping(value="InsertUserDetails")
public String addUser(@ModelAttribute("userObj" )
		Register reg,Model model,BindingResult result)
{
	String sMsg="Data Is Inserted Successfully";
	String eMsg="Error In Insertion";
	
	
	Register rg=logServ.addUserDetails(reg);
	Login lg=logServ.addUser(new Login(reg.getUname(),reg.getPwd()));
	
	if(rg!=null && lg!=null)
	{
		model.addAttribute("MsgObj", sMsg);
	}
	else
	{
		model.addAttribute("MsgObj", eMsg);
	}
	/*ArrayList<Register> uList=logServ.fetchAllUser();
	model.addAttribute("UserListObj", uList);*/
	return "redirect:/ShowAllUserDetails.obj";
}

@RequestMapping(value="/DeleteUser")
public String delUser(@RequestParam("unm")
		String name)
{
	logServ.deleteUser(name);
	return "redirect:/ShowAllUserDetails.obj";
	
}
@RequestMapping(value="/ShowAllUserDetails")
public String dispAllUserDetails(Model model)
{
	ArrayList<Register> uList=logServ.fetchAllUser();
	model.addAttribute("UserListObj", uList);
	return "ListAllUser";
}


}
	


