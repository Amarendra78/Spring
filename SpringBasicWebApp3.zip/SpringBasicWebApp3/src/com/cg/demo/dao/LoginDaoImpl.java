package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;
@Repository
@Transactional
public class LoginDaoImpl implements ILoginDao 
{

	@PersistenceContext
	EntityManager entityMgr=null;
	public EntityManager getEntityMgr() {
		return entityMgr;
	}
	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}
	
	@Override
	public Login validateUser(Login user) 
	{
		Login usr=	entityMgr.find(Login.class,
			user.getUsername());
		return usr;
			
	}
	@Override
	public Register addUserDetails(Register reg) {
		entityMgr.persist(reg);
		Register obj=entityMgr.find(Register.class, reg.getUname());
		return obj;
	}
	@Override
	public Login addUser(Login log) {
		entityMgr.persist(log);
		Login obj=entityMgr.find(Login.class, log.getUsername());
		return obj;
	}
	@Override
	public ArrayList<Register> fetchAllUser() {
		String selQ="SELECT reg FROM Register reg";
		TypedQuery<Register> tq=entityMgr.createQuery(selQ,Register.class);
		ArrayList<Register> uList=(ArrayList)tq.getResultList();
		
		return uList;
	}
	@Override
	public void deleteUser(String unm) {
	Register re=entityMgr.find(Register.class,unm);
	Login log=entityMgr.find(Login.class, unm);
	if(re!=null) {
		entityMgr.remove(re);
	}else {
		System.out.println("User not registered");
	}
	
	if(log!=null) {
		entityMgr.remove(log);
	}else {
		System.out.println("User not found");
	}
	
	
	System.out.println("removed.................");
	
	}
	
	
}
