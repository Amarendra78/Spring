package com.cg.demo.dao;

import java.util.ArrayList;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;

public interface ILoginDao 
{
	public Login validateUser(Login user);
	public Register addUserDetails(Register reg);
	public Login addUser(Login log);
	public ArrayList<Register> fetchAllUser();
	public void deleteUser(String unm);
}
