package com.cg.ems.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Employee;
import com.cg.User;

public class TestEmpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
    Employee e1 = (Employee)ctx.getBean("emp1");
    System.out.println("Emp Info : "+e1);
    System.out.println("HashCode of e1 = "+e1.hashCode());
    
    Employee e2 = (Employee)ctx.getBean("emp1");
    System.out.println("Emp Info : "+e2);
    System.out.println("HashCode of e2:"+e2.hashCode());
    
    System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _");
    User u1=(User)ctx.getBean("user1");
    System.out.println(" User Credentials : "+u1);
	}

}
