package com.cg;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import org.springframework.beans.PropertyEditorRegistrar;
import org.springframework.beans.PropertyEditorRegistry;
import org.springframework.beans.propertyeditors.CustomDateEditor;

public class MyDOBEditor  implements PropertyEditorRegistrar {
	
	public void registerCustomEditors(PropertyEditorRegistry register)
	{
		register.registerCustomEditor(LocalDate.class, new CustomDateEditor(new SimpleDateFormat("dd-MM-yyyy"),false));
	}
}
