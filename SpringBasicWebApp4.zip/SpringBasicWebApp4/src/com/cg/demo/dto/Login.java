package com.cg.demo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="cg_users")
public class Login 
{
	@Id
	@Column(name="user_name")
	@NotEmpty(message="User name is mandatory")
	@Size(min=5,message="username should have minimum 5 characters")
	private String username;
	
	@NotEmpty(message="password is mandatory")
	//@Pattern(regexp="[A-Z][a-z]+", message="should start with cap only character allowed")
	private String password;
	public Login()
	{
	
	}
	public Login(String username, String password) 
	{
		super();
		this.username = username;
		this.password = password;
	}
	@Override
	public String toString() 
	{
		return "Login [username=" + username + ", password=" + password + "]";
	}
	public String getUsername() 
	{
		return username;
	}
	public void setUsername(String username) 
	{
		this.username = username;
	}
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	

}
