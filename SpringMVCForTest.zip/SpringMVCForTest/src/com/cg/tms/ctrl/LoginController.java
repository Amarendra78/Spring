package com.cg.tms.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;
import com.cg.tms.service.LoginService;


@Controller
public class LoginController {

	@Autowired
	LoginService logser;
	
	
	public LoginService getLogser() {
		return logser;
	}
	public void setLogser(LoginService logser) {
		this.logser = logser;
	}


	/********************* ShowLoginPage.obj**************************/
	
	@RequestMapping(value="/ShowLoginPage")
	public String displayLoginPage(Model model)
	{
		Login lgg=new Login();
		lgg.setUserName("Please enter your userId");
		model.addAttribute("log",lgg);
		return "Login";
	}
	
	
	/*************validate User(ValidateUser.obj) ***********************/
	@RequestMapping(value="/ValidateUser")
	public String validateUser(
			@ModelAttribute("log")
			@Valid
			Login lgg,BindingResult result,Model model)
	 {
		if(result.hasErrors())
		{
			return "Login";
		}
		else
		{
		System.out.println("user entered :"+lgg);
		if(logser.validateUser(lgg))
		{
			return "Success";
		}else
		{
			model.addAttribute("MsgObj","Please Check Ur Password");
			return "Login";
		}
	}
	}
	
	/***************************Add A Trainee**************************/

	@RequestMapping(value="/ShowAddTraineePage")
	public String dispRegisterPage(Model model)
	{
		Trainee tra=new Trainee();
		ArrayList<String> domain=new ArrayList<String>();
		domain.add("java");
		domain.add("cloud");
		domain.add("Testing");
		domain.add("c++");
		model.addAttribute("domainobj",domain);
				
		model.addAttribute("traObj",tra);
		
		return "AddTrainee";
	}
	
	@RequestMapping(value="/AddTrainee")
	public String insertUserDetails(@ModelAttribute("traObj")
			Trainee tra,BindingResult result,Model model)
	{
		/*Login log=new Login(reg.getUname(),
				reg.getPwd());
		logser.addUser(log);*/
		
		logser.addUserDetails(tra);
		ArrayList<Trainee> traineeList=logser.getAllUserDetails();
		//System.out.println("Size is="+traineeList.size());
		model.addAttribute("TraineeListObj", traineeList);
		return "ListAllUser";
	  }
	
	
	/*******************Delete a Trainee******************************************************************/
	
	@RequestMapping(value="/ShowDeleteUser")
	public String displayDeletePage1(Model model)
	{
	   Trainee t=new Trainee();
	   t.setId("Enter your Id");
		model.addAttribute("train",t);
		return "Delete";
	}
	
	
	
	@RequestMapping(value="/DeleteUser")
	public String deleteUserDetails(
			@ModelAttribute("train")
			Trainee uid,Model model)
	{
		
		String Id=uid.getId();
		logser.deleteUserDetails(Id);
		ArrayList<Trainee> userList=logser.getAllUserDetails();
		model.addAttribute("TraineeListObj", userList);
		return "ListAllUser";
		
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/*************************Show All Employee************************************************************/
	@RequestMapping(value="/ShowAllTrainee")
	public String displayAllTrainee(Model model)
	{
		ArrayList<Trainee> traineeList=logser.getAllUserDetails();
		System.out.println(traineeList);
		model.addAttribute("TraineeListObj", traineeList);
		return "ListAllUser";
	}
	
	/*****************************************Show a trainee based on ID ************************************/
	
	@RequestMapping(value="/ShowTrainee")
	public String searchTrainee(Model model)
	{
	   Trainee t=new Trainee();
	   t.setId("Enter your Id");
		model.addAttribute("tra",t);
		return "Search";
	}
	
	
	
	@RequestMapping(value="/SearchTrainee")
	public String searchTraineeDetails(
			@ModelAttribute("tra")
			Trainee uid,Model model)
	{
		
		String Id=uid.getId();
		ArrayList<Trainee> userList=logser.searchTraineeDetails(Id);
		model.addAttribute("TraineeListObj", userList);
		return "ListAllUser";
		
	}

	/*************************************************update trainee details*******************************/
	
	@RequestMapping(value="/ShowUpdatePage")
	public String InputIdupdate(Model model)
	{
	   Trainee t=new Trainee();
		model.addAttribute("updtrain",t);
		return "InputIdUpdate";
	}
	
	@RequestMapping(value="/UpdateTrainee")
	public String updateTrainee(
			@ModelAttribute("updtrain")
	        Trainee uid,Model model)
	{
		ArrayList<String> domain=new ArrayList<String>();
		domain.add("java");
		domain.add("cloud");
		domain.add("Testing");
		domain.add("c++");
		model.addAttribute("domainobj",domain);
		model.addAttribute("updtra",uid);
		return "Update";
	}
	
	@RequestMapping(value="/SendUpdateTrainee")
	public String updateTraineeDetails(
			@ModelAttribute("traObj")
			Trainee traupd,Model model)
	{
		
		logser.updateTraineeDetails(traupd);
		
		ArrayList<Trainee> traineeList=logser.getAllUserDetails();
		model.addAttribute("TraineeListObj", traineeList);
		return "ListAllUser";
		
	}
	
}
