package com.cg.tms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.tms.dao.LoginDao;
import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginDao logDao;
		
	public LoginDao getLogDao() {
		return logDao;
	}

	public void setLogDao(LoginDao logDao) {
		this.logDao = logDao;
	}


	@Override
	public boolean validateUser(Login user) {
Login daouser=logDao.getUserById(user.getUserName());
		
		if(user.getUserName().equalsIgnoreCase(daouser.getUserName())&&
		(user.getUserPass().equalsIgnoreCase(daouser.getUserPass())))
		{
			return true;
		}
		else
		{
		return false;
		}
	}

	@Override
	public Login getUserById(String unm) {
		return logDao.getUserById(unm);
	}

	@Override
	public void addUserDetails(Trainee tra) {
		// TODO Auto-generated method stub
		 logDao.addUserDetails(tra);
	}

	@Override
	public ArrayList<Trainee> getAllUserDetails() {
		// TODO Auto-generated method stub
		return logDao.getAllUserDetails();
	}

	@Override
	public boolean deleteUserDetails(String uid) {
		// TODO Auto-generated method stub
		return logDao.deleteUserDetails(uid);
	}

	@Override
	public ArrayList<Trainee> searchTraineeDetails(String id) {
		// TODO Auto-generated method stub
		return logDao.searchTraineeDetails(id);
	}

	@Override
	public void updateTraineeDetails(Trainee traupd) {
		 logDao.updateTraineeDetails(traupd);
	}

}
