package com.cg.tms.service;

import java.util.ArrayList;

import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;

public interface LoginService {
	
	public Login getUserById(String unm);
	public boolean validateUser(Login user);
	public void addUserDetails(Trainee tra);
	public ArrayList<Trainee> getAllUserDetails();
	public boolean deleteUserDetails(String uid);
	public ArrayList<Trainee> searchTraineeDetails(String id);
	public void updateTraineeDetails(Trainee traupd);
}
