package com.cg.tms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;


import org.springframework.stereotype.Repository;

import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;

@Repository
@Transactional
public class LoginDaoImpl implements LoginDao {

	@PersistenceContext
	EntityManager em;
	@Override
	public Login getUserById(String unm) {
		System.out.println(" In login dao getUserById");
		Login user=em.find(Login.class,unm);
		return user;
	}
	
	//////////////Query To add ////////////////////////////////////////////////////////////////////
	@Override
	public void addUserDetails(Trainee tra) {
		em.persist(tra);
		
	}
	
	
	////////////////////////////Query to search all trainee//////////////////////////////////
	@Override
	public ArrayList<Trainee> getAllUserDetails() {
        String selectUserQry="Select reg FROM Trainee reg";
		
		TypedQuery<Trainee> tq=em.createQuery(selectUserQry,Trainee.class);
		ArrayList<Trainee> userL=(ArrayList<Trainee>)tq.getResultList();
		return userL;
	}
	
	/////////////////////Query for delete //////////////////////////////////////
    public boolean deleteUserDetails(String uid) {
		System.out.println("In login DAO ");
		Trainee user=em.find(Trainee.class,uid);
		em.remove(user);
		return true;
	}
    
    
    ////////////////////////query to search trainee based on Id///////////////////////////////////////////////
	@Override
	public ArrayList<Trainee> searchTraineeDetails(String id) {
		
		/*here id will be the parameter in Login class else it will give error*/
		
        String selectUserQry="Select reg FROM Trainee reg WHERE reg.id LIKE :uid";
		
		TypedQuery<Trainee> tq=em.createQuery(selectUserQry,Trainee.class);
		tq.setParameter("uid", "%"+id+"%");
		return (ArrayList<Trainee>) tq.getResultList();
		
	}

	@Override
	public void updateTraineeDetails(Trainee traupd) {
		
		String Id=traupd.getId();
		String tame=traupd.getName();
		String Location=traupd.getLocation();
		String Domain=traupd.getDomain();
		
		Query query=em.createQuery("UPDATE Trainee SET name=:pame, location=:Location, domain=:Domain WHERE id=:Id");
		
		query.setParameter("Id",Id);
		query.setParameter("pame", tame);
		query.setParameter("Location",Location);
		query.setParameter("Domain", Domain);

		int count=query.executeUpdate();
		if(count!=0)
		System.out.println("Details Updated ");
		else
			System.out.println("Not Updated");
		
		
	}

}
