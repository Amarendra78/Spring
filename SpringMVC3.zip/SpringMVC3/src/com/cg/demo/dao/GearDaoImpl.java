package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.QueryMaster;



@Repository
@Transactional
public class GearDaoImpl implements IGearDao
{

	@PersistenceContext
	EntityManager em=null;
	public EntityManager getEm() 
	{
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	@Override
	public ArrayList<QueryMaster> fetchAllUsers(int id1) 
	{

		String selQ="select reg from QueryMaster reg where queryId='"+id1+"'";
		TypedQuery<QueryMaster> tq=em.createQuery(selQ,QueryMaster.class);
		ArrayList<QueryMaster> uList=(ArrayList)tq.getResultList();
		return uList;
	}

	@Override
	public void ModifyGearDetails(int id1,String sol)
	{
		QueryMaster reg=em.find(QueryMaster.class,id1);
		reg.setSolutionsGiven(sol);
		em.merge(reg);
	}

	
}
