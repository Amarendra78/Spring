package com.cg.demo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="query_master")
public class QueryMaster
{

	@Id
	@Column(name = "query_id",length=10)
	private int queryId;
	
	@Column(name = "technology",length=10)
	private String technologyName;
	
	
	@Column(name = "query_raised_by",length=10)
	private String queryRaisedBy;
	
	@Column(name = "solutions",length=10)
	private String solutions;
	
	@Column(name = "solution_given_by",length=10)
	private String solutionsGiven;

	@Override
	public String toString() {
		return "QueryMaster [queryId=" + queryId + ", technologyName=" + technologyName + ", queryRaisedBy="
				+ queryRaisedBy + ", solutions=" + solutions + ", solutionsGiven=" + solutionsGiven + "]";
	}

	public int getQueryId() {
		return queryId;
	}

	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}

	public String getTechnologyName() {
		return technologyName;
	}

	public void setTechnologyName(String technologyName) {
		this.technologyName = technologyName;
	}

	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}

	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}

	public String getSolutions() {
		return solutions;
	}

	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}

	public String getSolutionsGiven() {
		return solutionsGiven;
	}

	public void setSolutionsGiven(String solutionsGiven) {
		this.solutionsGiven = solutionsGiven;
	}

	public QueryMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
