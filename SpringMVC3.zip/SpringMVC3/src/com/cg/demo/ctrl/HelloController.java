
package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.demo.dto.QueryMaster;

@Controller
@RequestMapping("/helloctrl")
public class HelloController 
{

	
	@RequestMapping(value="/ShowLoginPage")
	public String dispHomePage(Model model)
	{
		QueryMaster lg = new QueryMaster();
		model.addAttribute("queryM", lg);
		return "Search";
		
	}
	
}