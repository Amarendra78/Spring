package com.cg.demo.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.demo.dto.QueryMaster;

import com.cg.demo.service.IGearService;
@Controller
public class GearController
{
	int id1;
	@Autowired
	IGearService gearSer=null;
	
	public IGearService getGearSer() {
		return gearSer;
	}

	public void setGearSer(IGearService gearSer) {
		this.gearSer = gearSer;
	}


	@RequestMapping(value="/ShowAllQueryDetails", method = RequestMethod.POST)
	public String detailsGear(@ModelAttribute("queryM") @Valid QueryMaster lgg, BindingResult result, Model model)
	{
		QueryMaster reg=new QueryMaster();
		model.addAttribute("userObj", reg);
		ArrayList<String> domain=new ArrayList<String>();
		domain.add("Uma");
		domain.add("Rahul");
		domain.add("Kavita");
		domain.add("Hema");
		model.addAttribute("cDomain",domain);
		id1=lgg.getQueryId();
		ArrayList<QueryMaster> uList=gearSer.fetchAllUsers(id1);
		model.addAttribute("msgObj",id1);
		if(uList.isEmpty())
		{
			return "NotFound";
		}
		else
		{model.addAttribute("UserListObj", uList);
		return "GearDetails";}
			
	}
	@RequestMapping(value="/ShowAllQueryDetails1", method = RequestMethod.POST)
	public String modifyGear(@ModelAttribute("userObj") @Valid QueryMaster lgg, BindingResult result, Model model)
	{
	   
		String sol=lgg.getSolutionsGiven();
		gearSer.ModifyGearDetails(id1,sol);
		model.addAttribute("msgObj",id1);
		return "Mod";
		
	}
}
