package com.cg.beans;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Main {
	public static void main(String[] args) {
		Resource rsc=new ClassPathResource("beans.xml");
		BeanFactory factory=new XmlBeanFactory(rsc);
		Employee emp=(Employee) factory.getBean("e1");
		
		
		
		/*emp.setEmpId(111);
		emp.setName("shruthi");
		emp.setLocation("managlore");
		emp.setSalary(40000);*/
		Employee emp2=(Employee) factory.getBean("e2");
		System.out.println(emp2);
	}

}
