package com.cg.beans;

import java.time.LocalDate;

public class Employee {
	private int empId;
	private String name;
	private String location;
	private double salary;
	private LocalDate joinDate;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String name, String location, double salary) {
		this.empId = empId;
		this.name = name;
		this.location = location;
		this.salary = salary;
		
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", location=" + location + ", salary=" + salary
				+ ", joinDate=" + joinDate + "]";
	}
	

}
