package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.demo.dto.Login;
import com.cg.demo.service.ILoginService;
import com.cg.demo.service.ILoginService;


@Controller
//@RequestMapping("/loginCtrl")  
public class LoginController {
	
	/*@RequestMapping("/ShowLoginPage")
	public String showLoginPage()
	{
		return "Login";
	}*/
	@Autowired
	ILoginService  logServ= null;
	public ILoginService getLogServ() {
		return logServ;
	}
	public void setLogServ(ILoginService logServ) {
		this.logServ = logServ;
	}
	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String showLoginPage(Model model)
	{
		Login lg=new Login();
		String msg="Today is: "+LocalDate.now();
		model.addAttribute("msgObj", msg);
		model.addAttribute("loginObj", lg);
		return "Login";

	}
	
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginObj") Login lgg,Model model)
	{
		Login user=logServ.validateUser(lgg);
		if(user!=null)
		{
			if(user.getPassword().equalsIgnoreCase(lgg.getPassword()))
					{
				String msg="Welcome U R Valid User :"+user.getUsername();
					model.addAttribute("MsgObj", msg);
			return "Success";
		}
		else 
			{
		String msg="Sorry  InValid User";
			model.addAttribute("MsgObj", msg);
			return "Login";
		}
	
		
	}
		else
		{
			return "Register";
		}
		}
	}


