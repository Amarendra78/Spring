package com.cg.demo.dao;

import com.cg.demo.dto.Login;

public interface ILoginDao 
{
	public Login validateUser(Login user);

}
