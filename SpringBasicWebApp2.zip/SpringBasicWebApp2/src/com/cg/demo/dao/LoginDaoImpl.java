package com.cg.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.Login;
@Repository
public class LoginDaoImpl implements ILoginDao 
{

	@PersistenceContext
	EntityManager entityMgr=null;
	public EntityManager getEntityMgr() {
		return entityMgr;
	}
	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}
	
	@Override
	public Login validateUser(Login user) 
	{
		Login usr=	entityMgr.find(Login.class,
			user.getUsername());
		return usr;
			
	}
	
	
}
