package com.cg.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.ILoginDao;

import com.cg.demo.dto.Login;
@Service
public class LoginServiceImpl implements ILoginService 
{
	@Autowired
	ILoginDao loginDao=null;
	
	
	public ILoginDao getLoginDao() {
		return loginDao;
	}


	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}


	@Override
	public Login validateUser(Login user) {

		return loginDao.validateUser(user);
	}

}
