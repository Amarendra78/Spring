package com.cg.ems.ctrl;
import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

//http:localhost:8082/SpringMVCBasicDemo/helloCtrl/ShowWelcomePage
@Controller
@RequestMapping("helloCtrl")
public class HelloController
{
	@RequestMapping(value="/ShowWelcomePage")
	public ModelAndView dispWelcomePage()
	{
		LocalDate today=LocalDate.now();
		ModelAndView modelView=new ModelAndView("Welcome","todayObj",today);
		
		return modelView;
	}

}
