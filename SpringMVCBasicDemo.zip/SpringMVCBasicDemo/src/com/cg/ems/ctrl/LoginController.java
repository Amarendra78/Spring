package com.cg.ems.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;
import com.cg.ems.service.LoginService;

@Controller
public class LoginController {
	
	@Autowired
	LoginService logser;
	
	
	public LoginService getLogser() {
		return logser;
	}

	public void setLogser(LoginService logser) {
		this.logser = logser;
	}

	@RequestMapping(value="/ShowLoginPage")
	public String displayLoginPage(Model model)
	{
		Login lgg=new Login();
		lgg.setUserName("Enter ur userID here");
		model.addAttribute("log",lgg);
		return "Login";
	}

	/*************validate User ***********************/
	@RequestMapping(value="/ValidateUser")
	public String validateUser(
			@ModelAttribute("log")
			@Valid
			Login lgg,BindingResult result,Model model)
	 {
		if(result.hasErrors())
		{
			return "Login";
		}
		else
		{
		System.out.println("user entered :"+lgg);
		if(logser.validateUser(lgg))
		{
			return "Success";
		}else
		{
			model.addAttribute("MsgObj","Please Check Ur Password");
			return "Login";
		}
	}
	}
	/********************* showRegister.obj**************************/
	@RequestMapping(value="/ShowRegisterPage")
	public String dispRegisterPage(Model model)
	{
		RegisterDto reg=new RegisterDto();
		ArrayList<String> cityList=new ArrayList<String>();
		cityList.add("Pune");
		cityList.add("Noida");
		cityList.add("Ghaziabad");
		cityList.add("Mumbai");
		model.addAttribute("cityListobj",cityList);
		
        ArrayList<String> skillList=new ArrayList<String>();		
		skillList.add("java");
		skillList.add("Oracle");
		skillList.add("Html");
		skillList.add("BI");
		model.addAttribute("skillListobj",skillList);
		
		model.addAttribute("regObj",reg);
		
		return "Register";
	}
	
	@RequestMapping(value="/AddUserDetails")
	public String insertUserDetails(
			@ModelAttribute("regObj")
			RegisterDto reg,BindingResult result,Model model)
	{
		Login log=new Login(reg.getUname(),
				reg.getPwd());
		logser.addUser(log);
		logser.addUserDetails(reg);
		ArrayList<RegisterDto> userList=logser.getAllUserDetails();
		model.addAttribute("UserListObj", userList);
		return "ListAllUser";
	  }
	
	@RequestMapping(value="/DeleteUser")
	public String deleteUserDetails(
			@RequestParam("uid")
			String uid,Model model)
	{
		logser.deleteUser(uid);
		logser.deleteUserDetails(uid);
		ArrayList<RegisterDto> userList=logser.getAllUserDetails();
		model.addAttribute("UserListObj", userList);
		return "ListAllUser";
		
	}
	
	@RequestMapping(value="/ShowUpdatePage")
	public String redirect(
			@RequestParam("uid")
			String uid,Model model)
	{
		RegisterDto reg=logser.getUserDetailsById(uid);
		model.addAttribute("updObj",reg);
		return "Update";
		
	}
	
	@RequestMapping(value="/Update")
	public String UpdateUserDetails(
			@ModelAttribute("updObj")
			RegisterDto reg,BindingResult result,Model model)
	{
				logser.updateUserDetails(reg);
		ArrayList<RegisterDto> userList=logser.getAllUserDetails();
		model.addAttribute("userListObj",userList);
		return "ListAllUser";
		
	}
}
