package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;

@Repository
@Transactional
public class LoginDaoImpl implements LoginDao{
    
	@PersistenceContext
	EntityManager em;
	@Override
	public Login getUserById(String unm) {
		
		System.out.println(" In login dao getUserById");
		Login user=em.find(Login.class,unm);
		return user;
	}
	@Override
	public RegisterDto addUserDetails(RegisterDto userDetails) {
		
		em.persist(userDetails);
		RegisterDto reg=em.find(RegisterDto.class, userDetails.getUname());
		return reg;
	}
	@Override
	public ArrayList<RegisterDto> getAllUserDetails() {
		
		String selectUserQry="Select reg "+"FROM RegisterDto reg";
		
		TypedQuery<RegisterDto> tq=em.createQuery(selectUserQry,RegisterDto.class);
		ArrayList<RegisterDto> userL=(ArrayList)tq.getResultList();
		return userL;
	}
	@Override
	public Login addUser(Login user) {
		em.persist(user);
		Login uu=em.find(Login.class,
		user.getUserName());
		// TODO Auto-generated method stub
		return uu;
	}
	@Override
	public boolean deleteUser(String uid) {
		Login user1=em.find(Login.class,uid);
		em.remove(user1);
		return true;
	}
	@Override
	public boolean deleteUserDetails(String uid) {
		
		RegisterDto userDet1=em.find(RegisterDto.class,uid);
		em.remove(userDet1);
		return true;
	}
	@Override
	public RegisterDto getUserDetailsById(String uid) {
		RegisterDto userDet1=em.find(RegisterDto.class,uid);
		return userDet1;
	}
	@Override
	public boolean updateUserDetails(RegisterDto reg) {
		RegisterDto userDet1=em.find(RegisterDto.class,reg.getUname());
		
		Query query= (Query) em.createQuery("UPDATE RegisterDto SET firstName=:a, lastname=:b, gender=:c, city=:d, email=:e, skillSetStr=:f WHERE uname=:g");
		query.setParameter("a", reg.getFirstName());
		query.setParameter("b", reg.getLastname());
		query.setParameter("c", reg.getGender());
		query.setParameter("d", reg.getCity());
		query.setParameter("e", reg.getEmail());
		query.setParameter("f", reg.getSkillSetStr());
		query.setParameter("g", reg.getUname());
		int rowUpdated=query.executeUpdate();
		System.out.println("entitities Updated: "+rowUpdated);
		return true;
	}
	
	

}
