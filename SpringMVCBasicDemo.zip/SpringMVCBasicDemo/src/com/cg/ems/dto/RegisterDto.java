package com.cg.ems.dto;


import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="cg_userdetails")
public class RegisterDto 
{
	@Id
	@Column(name="user_name")
  private String uname;
	
 @Transient
  private String pwd;
	
 @Transient
  private String confPwd;
 
 @Column(name="first_name")
  private String firstName;
 
 @Column(name="last_name")
  private String lastname;
 
 @Column(name="user_email")
  private String email;
 
 @Transient
  private String[] skillSet[];
 
 @Column(name="user_gender")
  private char gender;
 
 @Column(name="user_city")
  private String city;
 
 @Column(name="user_skill")
  private String skillSetStr;
 
public RegisterDto() {
	super();
	// TODO Auto-generated constructor stub
}
public RegisterDto(String uname, String pwd, String confPwd, String firstName, String lastname, String email,
		String[][] skillSet, char gender, String city, String skillSetStr) {
	super();
	this.uname = uname;
	this.pwd = pwd;
	this.confPwd = confPwd;
	this.firstName = firstName;
	this.lastname = lastname;
	this.email = email;
	this.skillSet = skillSet;
	this.gender = gender;
	this.city = city;
	this.skillSetStr = skillSetStr;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public String getConfPwd() {
	return confPwd;
}
public void setConfPwd(String confPwd) {
	this.confPwd = confPwd;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String[][] getSkillSet() {
	return skillSet;
}
public void setSkillSet(String[][] skillSet) {
	this.skillSet = skillSet;
}
public char getGender() {
	return gender;
}
public void setGender(char gender) {
	this.gender = gender;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getSkillSetStr() {
	return skillSetStr;
}
public void setSkillSetStr(String skillSetStr) {
	this.skillSetStr = skillSetStr;
}


@Override
public String toString() {
	return "RegisterDto [uname=" + uname + ", pwd=" + pwd + ", confPwd=" + confPwd + ", firstName=" + firstName
			+ ", lastname=" + lastname + ", email=" + email + ", skillSet=" + Arrays.toString(skillSet) + ", gender="
			+ gender + ", city=" + city + ", skillSetStr=" + skillSetStr + "]";
}
  
  
  
  
	
}
