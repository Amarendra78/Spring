package com.cg.ems.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Employee;

public class TestEmpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
    Employee emp2 = (Employee)ctx.getBean("emp2");
    System.out.println("Emp Info : "+emp2);
    
    
   
	}

}
