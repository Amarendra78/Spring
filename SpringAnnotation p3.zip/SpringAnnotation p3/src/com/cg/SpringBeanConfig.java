package com.cg;
import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
@ComponenetScan(basePakages="com.cg")
public class SpringBeanConfig {

	@Bean
	public ArrayList<String> getEmpWorkLoc()
	{
		ArrayList<String> cityList=new ArrayList<String>();
		cityList.add("Noida");
		cityList.add("pube");
		cityList.add("Mumbai");
		return cityList;
	}
	
	public static PropertySourcesPlaceHolderConfigurer propertyConfigdev()
	{
		return new PropertySourcesPlaceholderConfigurer();
	}
}
