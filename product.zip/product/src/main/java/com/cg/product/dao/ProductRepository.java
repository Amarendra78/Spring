package com.cg.product.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.product.dto.Product;



@Repository
@Transactional
public interface ProductRepository extends JpaRepository<Product, String>{

	@Query("SELECT userList FROM Product userList")
	public ArrayList<Product> getAllUsers();
	
    @Query("SELECT log FROM Product log WHERE log.Name=:unm")
    public Product getUserbyUserName(@Param("unm") String unm);
    
    @Modifying
    @Query("DELETE FROM Product log WHERE log.Name=:unm")
    public void deleteUserbyUserName(@Param("unm") String unm);
    
    @Modifying
    @Query("Update Product log SET log.Price=:pr,log.Id=:id WHERE log.Name=:name")
    public void updateUserInfo(@Param("pr")
    String pr,@Param("id")String id,@Param("name") String name);
    
	
}
