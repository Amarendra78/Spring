package com.cg.product.service;

import java.util.ArrayList;

import com.cg.product.dto.Product;



public interface ProductService {

	
	public ArrayList<Product> getAllUsers();
	public Product addUser(Product log);
	public Product getUserbyUserName(String unm);
	public void deleteUserbyUserName(String unm);
    public void updateUserInfo(String pr,String id,String name);
}
