package com.cg.product.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {

	@Id
	@Column(name="id",length=10)
	private String Id;
	
	@Column(name="name",length=20)
	private String Name;

	@Column(name="price",length=5)
	private String Price;

	

	public Product() {
		super();
	}

	public Product(String id, String name, String price) {
		super();
		Id = id;
		Name = name;
		Price = price;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	@Override
	public String toString() {
		return "Product [Id=" + Id + ", Name=" + Name + ", Price=" + Price + "]";
	}

	
	
}
