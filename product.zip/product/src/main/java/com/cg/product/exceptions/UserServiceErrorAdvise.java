package com.cg.product.exceptions;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class UserServiceErrorAdvise {
@ResponseBody
@ResponseStatus(value=HttpStatus.NOT_FOUND)
@ExceptionHandler(value=Exception.class)
	protected ErrorInfo handelConflicts(Exception e,HttpServletRequest request)
	{
		String bodyOfResponse=e.getMessage();
	System.out.println("HandleConflict error msg "+bodyOfResponse);
	String url=request.getRequestURL().toString();
	System.out.println("saffd= "+bodyOfResponse+"kjhjjk= "+url);
	return new ErrorInfo(url,bodyOfResponse);
	}
	
@ExceptionHandler({UserNotFoundException.class,SQLException.class})
protected ResponseEntity<String>handle2 (UserNotFoundException ee)
{
return error(HttpStatus.INTERNAL_SERVER_ERROR,ee);
}

protected ResponseEntity<String>error
(HttpStatus status,UserNotFoundException ee)
{
return ResponseEntity.status(status).body(ee.getMessage());
}

}
