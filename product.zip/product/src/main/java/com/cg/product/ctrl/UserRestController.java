package com.cg.product.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.Product;
import com.cg.product.exceptions.UserNotFoundException;
import com.cg.product.service.ProductService;
import com.cg.product.service.ProductServiceImpl;



@RestController
public class UserRestController {

	@Autowired
	ProductService logSer;
	
	@GetMapping(value="/showAllUsers",headers="Accept=application/json")
	public ArrayList<Product> showAllUsers()
	{
		System.out.println("----------userRest Controller Called-------------");	
		return logSer.getAllUsers();	
	}
	
	@PostMapping(value="/addUser",consumes=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json",
			produces=MediaType.APPLICATION_JSON_VALUE
			)
	public Product createUser(@RequestBody Product log)
	{
		logSer.addUser(log);
		Product lgg=logSer.getUserbyUserName(log.getName());
		return lgg;
	}
	
	@DeleteMapping(value="/deleteUser/{uid}",
			headers="Accept=application/json"
	)
	public String deleteUser(@PathVariable("uid") String unm)
	{
		 logSer.deleteUserbyUserName(unm);
         return ("  Deta Deleted ......");
	}
	
	@PutMapping(value="/user/update/",consumes=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public void updatUser(@RequestBody Product lg)
	{
		logSer.updateUserInfo(lg.getPrice(),lg.getId(),lg.getName());
	    System.out.println("Data updated in the table");
	}
	
	@GetMapping(value="searchUser/{uid}")
	public Product searchUserById(@PathVariable("uid") String unm)throws UserNotFoundException
	{
		Product lgg=logSer.getUserbyUserName(unm);
		if(lgg==null)
		{
			throw new UserNotFoundException("No USer With This Id ");
		}
		else
		{
			return lgg;
		}
	 }
	
	
}
